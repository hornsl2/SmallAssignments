#ifndef CHART_MAKER_CPP
#define CHART_MAKER_CPP

// Copyright (C) 2017 raodm@miamiOH.edu

#include "ChartMaker.h"

int
ChartMaker::run() {
    // A temporary dummy implementation or skeleton code that does 
    // absolutely nothing.
    return 0;
}

#endif
