// Copyright (C) 2017 raodm@miamiOH.edu

#include "ChartMaker.h"

// A simple main method to run ChartMaker
int main() {
    ChartMaker cm;
    return cm.run();
}
