#ifndef CHART_MAKER_H
#define CHART_MAKER_H

/** A top-level class to perform operations on chart objects based on
	user input.

	NOTE: You may modify/add as many methods or instance variables
	as needed to design this class.
	
	Copyright (C) 2017 raodm@miamiOH.edu
*/
class ChartMaker {
public:
    ChartMaker() {}
    ~ChartMaker() {}

    int run();

protected:
private:
};

#endif
